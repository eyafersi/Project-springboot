package com.restaurant.booking_system.repository;

import com.restaurant.booking_system.entities.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long> {
}