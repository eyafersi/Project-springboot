package com.restaurant.booking_system.services;

import com.restaurant.booking_system.entities.Commande;
import com.restaurant.booking_system.repository.CommandeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommandeService {

    private final CommandeRepository commandeRepository;

    public CommandeService(CommandeRepository commandeRepository) {
        this.commandeRepository = commandeRepository;
    }

    public List<Commande> getAllCommandes() {
        return commandeRepository.findAll();
    }

    public Commande getCommandeById(Long id) {
        return commandeRepository.findById(id).orElse(null);
    }

    public Commande saveCommande(Commande commande) {
        return commandeRepository.save(commande);
    }

    public void deleteCommande(Long id) {
        commandeRepository.deleteById(id);
    }

    // Méthode ajoutée pour la mise à jour
    public void updateCommande(Long id, Commande updatedCommande) {
        Commande existingCommande = getCommandeById(id);
        if (existingCommande != null) {
            existingCommande.setDate(updatedCommande.getDate());
            existingCommande.setClient(updatedCommande.getClient());
            // Si tu ajoutes d'autres champs dans Commande, pense à les mettre ici aussi
            commandeRepository.save(existingCommande);
 }
}
}