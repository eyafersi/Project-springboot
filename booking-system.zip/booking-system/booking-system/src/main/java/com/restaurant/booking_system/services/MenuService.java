package com.restaurant.booking_system.services;

import com.restaurant.booking_system.entities.Menu;
import com.restaurant.booking_system.repository.MenuRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {

    private final MenuRepository menuRepository;

    public MenuService(MenuRepository menuRepository) {
        this.menuRepository = menuRepository;
    }

    public List<Menu> getAllMenus() {
        return menuRepository.findAll();
    }

    public Menu getMenuById(Long id) {
        return menuRepository.findById(id).orElse(null);
    }

    public Menu saveMenu(Menu menu) {
        return menuRepository.save(menu);
    }

    public void deleteMenu(Long id) {
        menuRepository.deleteById(id);
    }

    public Menu updateMenu(Long id, Menu updatedMenu) {
        Menu existing = menuRepository.findById(id).orElse(null);
        if (existing != null) {
            existing.setNom(updatedMenu.getNom());
            existing.setDescription(updatedMenu.getDescription());
            existing.setPrix(updatedMenu.getPrix());
            return menuRepository.save(existing);
        }
        return null;
    }
}
