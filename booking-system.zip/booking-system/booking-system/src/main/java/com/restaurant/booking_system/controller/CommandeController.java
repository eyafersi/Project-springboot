package com.restaurant.booking_system.controller;

import com.restaurant.booking_system.entities.Commande;
import com.restaurant.booking_system.services.CommandeService;
import com.restaurant.booking_system.services.ClientService;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/commandes")
@CrossOrigin(origins = "*") // Pour autoriser les requêtes externes (API)
public class CommandeController {

    private final CommandeService commandeService;
    private final ClientService clientService;

    public CommandeController(CommandeService commandeService, ClientService clientService) {
        this.commandeService = commandeService;
        this.clientService = clientService;
    }

    // Partie MVC - Thymeleaf


    @Controller
    @RequestMapping("/commandes")
    public class ListCommandes {

        private final CommandeService commandeService;
        private final ClientService clientService;

        public ListCommandes(CommandeService commandeService, ClientService clientService) {
            this.commandeService = commandeService;
            this.clientService = clientService;
        }

        // Afficher la liste des commandes
        @GetMapping
        public String listCommandes(Model model) {
            List<Commande> commandes = commandeService.getAllCommandes();
            model.addAttribute("commandes", commandes);
            return "list-commandes";  // fichier src/main/resources/templates/list-commandes.html
        }

        // Formulaire création commande
        @GetMapping("/new")
        public String showCreateForm(Model model) {
            model.addAttribute("commande", new Commande());
            model.addAttribute("clients", clientService.getAllClients());
            return "add-edit-commande";  // fichier src/main/resources/templates/add-edit-commande.html
        }

        // Sauvegarder nouvelle commande
        @PostMapping("/save")
        public String saveCommande(@ModelAttribute("commande") Commande commande) {
            commandeService.saveCommande(commande);
            return "redirect:/commandes";
        }

        // Formulaire modification commande
        @GetMapping("/edit/{id}")
        public String showEditForm(@PathVariable Long id, Model model) {
            Commande commande = commandeService.getCommandeById(id);
            if (commande == null) {
                return "redirect:/commandes";  // si non trouvée redirige vers la liste
            }
            model.addAttribute("commande", commande);
            model.addAttribute("clients", clientService.getAllClients());
            return "add-edit-commande";
        }

        // Mise à jour commande existante
        @PostMapping("/update/{id}")
        public String updateCommande(@PathVariable Long id, @ModelAttribute("commande") Commande commande) {
            Commande existing = commandeService.getCommandeById(id);
            if (existing != null) {
                existing.setDate(commande.getDate());
                existing.setClient(commande.getClient());
                commandeService.saveCommande(existing);
            }
            return "redirect:/commandes";
        }

        // Supprimer une commande
        @GetMapping("/delete/{id}")
        public String deleteCommande(@PathVariable Long id) {
            commandeService.deleteCommande(id);
            return "redirect:/commandes";
        }
    }


    // Partie REST API - JSON

    @ResponseBody
    @GetMapping("/api")
    public List<Commande> getAllCommandesApi() {
        return commandeService.getAllCommandes();
    }

    @ResponseBody
    @GetMapping("/api/{id}")
    public Commande getCommandeById(@PathVariable Long id) {
        return commandeService.getCommandeById(id);
    }

    @ResponseBody
    @PostMapping("/api")
    public Commande createCommandeApi(@RequestBody Commande commande) {
        return commandeService.saveCommande(commande);
    }

    @ResponseBody
    @PutMapping("/api/{id}")
    public Commande updateCommandeApi(@PathVariable Long id, @RequestBody Commande updatedCommande) {
        Commande existing = commandeService.getCommandeById(id);
        if (existing != null) {
            existing.setDate(updatedCommande.getDate());
            existing.setClient(updatedCommande.getClient());
            return commandeService.saveCommande(existing);
        }
        return null;
    }

    @ResponseBody
    @DeleteMapping("/api/{id}")
    public void deleteCommandeApi(@PathVariable Long id) {
        commandeService.deleteCommande(id);
}

}