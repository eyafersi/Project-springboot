package com.restaurant.booking_system.services;

import com.restaurant.booking_system.entities.Client;
import com.restaurant.booking_system.repository.ClientRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ClientService {
    @Autowired

    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    // Récupérer tous les clients
    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    // Enregistrer un nouveau client
    public Client saveClient(Client client) {
        return clientRepository.save(client);
    }

    // Récupérer un client par son ID
    public Client getClientById(Long id) {
        return clientRepository.findById(id).orElse(null);
    }

    // Supprimer un client par son ID
    public void deleteClient(Long id) {
        clientRepository.deleteById(id);
    }

    // Mettre à jour un client existant
    public Client updateClient(Long id, Client clientDetails) {
        return clientRepository.findById(id)
                .map(client -> {
                    client.setNom(clientDetails.getNom());
                    client.setEmail(clientDetails.getEmail());
                    client.setTelephone(clientDetails.getTelephone());
                    client.setAdresse(clientDetails.getAdresse());
                    return clientRepository.save(client);
                })
                .orElse(null);
    }
}
