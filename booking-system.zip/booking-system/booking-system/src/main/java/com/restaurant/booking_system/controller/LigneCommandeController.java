package com.restaurant.booking_system.controller;

import com.restaurant.booking_system.entities.LigneCommande;
import com.restaurant.booking_system.entities.Commande;
import com.restaurant.booking_system.entities.Menu;
import com.restaurant.booking_system.services.LigneCommandeService;
import com.restaurant.booking_system.services.CommandeService;
import com.restaurant.booking_system.services.MenuService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.List;

@Controller
@RequestMapping("/lignes")
@CrossOrigin(origins = "*")
public class LigneCommandeController {

    private final LigneCommandeService ligneCommandeService;
    private final CommandeService commandeService;
    private final MenuService menuService;

    public LigneCommandeController(LigneCommandeService ligneCommandeService,
                                   CommandeService commandeService,
                                   MenuService menuService) {
        this.ligneCommandeService = ligneCommandeService;
        this.commandeService = commandeService;
        this.menuService = menuService;
    }

    // Partie MVC

    @GetMapping("/commande/{commandeId}")
    public String afficherLignesCommande(@PathVariable Long commandeId, Model model) {
        Commande commande = commandeService.getCommandeById(commandeId);
        List<LigneCommande> lignes = ligneCommandeService.findByCommandeId(commandeId);

        model.addAttribute("commande", commande);
        model.addAttribute("lignes", lignes);
        model.addAttribute("menus", menuService.getAllMenus());
        model.addAttribute("ligneCommande", new LigneCommande());

        return "lignes-commande";
    }

    @PostMapping("/commande/{commandeId}/add")
    public String ajouterLigneCommande(@PathVariable Long commandeId,
                                       @ModelAttribute("ligneCommande") LigneCommande ligneCommande) {

        Commande commande = commandeService.getCommandeById(commandeId);
        ligneCommande.setCommande(commande);

        if (ligneCommande.getMenu() != null && ligneCommande.getMenu().getId() != null) {
            Menu menu = menuService.getMenuById(ligneCommande.getMenu().getId());
            ligneCommande.setMenu(menu);
            ligneCommande.setPrixUnitaire(menu.getPrix());
        }

        ligneCommandeService.saveLigneCommande(ligneCommande);
        return "redirect:/lignes/commande/" + commandeId;
    }

    @GetMapping("/delete/{id}")
    public String supprimerLigne(@PathVariable Long id) {
        LigneCommande ligne = ligneCommandeService.getLigneCommandeById(id);
        Long commandeId = (ligne != null && ligne.getCommande() != null) ? ligne.getCommande().getId() : null;

        if (commandeId != null) {
            ligneCommandeService.deleteLigneCommande(id);
            return "redirect:/lignes/commande/" + commandeId;
        }

        return "redirect:/commandes";
    }

    // Partie API REST

    @ResponseBody
    @GetMapping("/api")
    public List<LigneCommande> getAllLignesCommandeApi() {
        return ligneCommandeService.getAllLignesCommande();
    }

    @ResponseBody
    @GetMapping("/api/{id}")
    public LigneCommande getLigneCommandeByIdApi(@PathVariable Long id) {
        return ligneCommandeService.getLigneCommandeById(id);
    }

    @ResponseBody
    @PostMapping("/api")
    public LigneCommande createLigneCommandeApi(@RequestBody LigneCommande ligneCommande) {
        return ligneCommandeService.saveLigneCommande(ligneCommande);
    }

    @ResponseBody
    @PutMapping("/api/{id}")
    public LigneCommande updateLigneCommandeApi(@PathVariable Long id,
                                                @RequestBody LigneCommande updated) {
        LigneCommande existing = ligneCommandeService.getLigneCommandeById(id);
        if (existing != null) {
            existing.setMenu(updated.getMenu());
            existing.setQuantite(updated.getQuantite());
            existing.setCommande(updated.getCommande());
            existing.setPrixUnitaire(updated.getPrixUnitaire());
            return ligneCommandeService.saveLigneCommande(existing);
        }
        return null;
    }

    @ResponseBody
    @DeleteMapping("/api/{id}")
    public void deleteLigneCommandeApi(@PathVariable Long id) {
        ligneCommandeService.deleteLigneCommande(id);
}
}