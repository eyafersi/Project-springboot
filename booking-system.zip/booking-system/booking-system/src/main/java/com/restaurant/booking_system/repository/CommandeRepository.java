package com.restaurant.booking_system.repository;

import com.restaurant.booking_system.entities.Commande;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommandeRepository extends JpaRepository<Commande, Long> {
}

