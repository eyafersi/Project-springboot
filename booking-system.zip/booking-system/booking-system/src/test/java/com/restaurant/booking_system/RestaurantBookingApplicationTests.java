package com.restaurant.booking_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
